<?php

$dbhost = '127.0.0.1';
$dbuser = 'dummy';
$dbpasswd = 'dummy';
$db = 'booking';

?>
